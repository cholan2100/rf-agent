%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4-10.0.4~ubuntu25.10.1*%
%TF.CreationDate,2026-09-09T05:17:26+00:00*%
%TF.ProjectId,bpf_100mhz_lc,6270665f-3130-4306-9d68-7a5f6c632e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4-10.0.4~ubuntu25.10.1) date 2026-09-09 05:17:26*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.250000X-0.250000X-0.475000X0.250000X-0.475000X0.250000X0.475000X-0.250000X0.475000X0*%
%ADD13C,2.200000*%
%ADD14RoundRect,0.218750X-0.218750X-0.381250X0.218750X-0.381250X0.218750X0.381250X-0.218750X0.381250X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X4500000Y-10000000D03*
D11*
X4500000Y-12540000D03*
%TD*%
D12*
%TO.C,C1*%
X13050000Y-10000000D03*
X14950000Y-10000000D03*
%TD*%
D13*
%TO.C,H2*%
X32000000Y-17000000D03*
%TD*%
D14*
%TO.C,L1*%
X19937500Y-10000000D03*
X22062500Y-10000000D03*
%TD*%
D10*
%TO.C,J2*%
X30500000Y-10000000D03*
D11*
X30500000Y-12540000D03*
%TD*%
D13*
%TO.C,H1*%
X3000000Y-3000000D03*
%TD*%
M02*
